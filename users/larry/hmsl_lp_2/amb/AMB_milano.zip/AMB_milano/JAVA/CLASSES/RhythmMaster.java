import com.cycling74.max.*;
import java.util.Vector;

public class RhythmMaster extends MaxObject implements Executable {
	private MaxClock clock;
	private double period = 300;
	private int grains = 60;
	private int numVoices = 1;
	private Voice[] voices;
	private boolean enable = false;
    private boolean slaveMode = false;
	private int globalTick = 0;
	private int carryGrain = 0;

	public RhythmMaster(Atom args[]) {
		clock = new MaxClock(this);
		/*
			first argument: number of voices.
		*/
		if (args.length > 0) {
			numVoices = args[0].getInt();
		}
		/* 
			second argument: period of master clock.
		*/
		if (args.length > 1) {
			period = args[1].isFloat() ? args[1].getFloat() : args[1].getInt();
		} 

		declareAttribute("period");
		declareAttribute("numVoices");
		declareAttribute("enable","getEnable","setEnable");
		declareAttribute("slaveMode");
		declareAttribute("grains");
		declareAttribute("carryGrain");

		// establish inlets, outlets, voices.  One of each for each, 
		// plus one global inlet and a period-bang outlet..
		voices = new Voice[numVoices];
		for (int i = 0; i < numVoices; i++) {	
			voices[i] = new Voice(i);
		}
		int[] lets = new int[numVoices + 1];
		for (int i = 0; i < numVoices + 1; i++) {
			lets[i] = DataTypes.ALL;
		}
		declareInlets(lets);
		declareOutlets(lets);	

		// assist:
		for (int i = 0; i < numVoices; i++) {
			setInletAssist(i, "Voice "+i+" control");
			setOutletAssist(i, "Voice "+i+" beats");
		}
		setInletAssist(numVoices, "Control All Voices");
		setOutletAssist(numVoices, "loop bang");
	}
	//****************************
	//               The clock
	//               ************
	public void execute() {
		for (int i = 0; i < voices.length; i++) {
			voices[i].tick();
		}
		if (enable && !slaveMode) {
			clock.delay( period / grains );
		}
		if (globalTick % grains == carryGrain) {
			outletBangHigh( voices.length );
		}
		globalTick++;
	}
	public void notifyDeleted() {
		clock.unset();
		clock.release();
		for (int i = 0; i < voices.length; i++) {
			voices[i].notifyDeleted();
		}
	}
	//*****************************
	//               Inlets
	//               **************
	/*
		Integer starts/stops global clock.  
	*/
	public void inlet(int in) {
		setEnable(in==1);
	}
	/*
		Bang resets clock.
	*/
	public void bang() {
		if (enable) {
			setEnable(false);
			setEnable(true);
		}
	}
	public void tick() {
		execute();
	}
	public void setEnable(boolean toenable) {
		if (toenable) {
			enable = true;
			clock.delay(0);
		} else {
			clock.unset();
			enable = false;
			globalTick = 0;
			for (int i = 0; i < voices.length; i++) {
				voices[i].stop();
			}
		}
	}
	public boolean getEnable() {
		return enable;
	}
	/*
		Other messages control individual voices by inlet.  
		Far right inlet controls all voices.
	*/
	public void anything(String message, Atom[] args) {
		if (getInlet() == voices.length) {
			for (int i = 0; i < voices.length; i++) {
				voices[i].command(message, args);
			}
		} else {
			voices[getInlet()].command(message,args);
		}
	}


	//*****************************
	//               Voices
	//               **************
	private class Voice implements Executable {
		// sequence related...
		private int mynum;
		private double[] sequence = new double[] {1};
		private double[] delays = new double[] {0};
		private Atom[] payload;

		// options...
		private double jitter = 0;
		private double cloud = 1;
		private double cut = 1;

		private boolean probs = true;
		private boolean bangs = false;
		private boolean jam = false;
		private boolean active = true;

		// timing control...
		private int tick = 0;
		private int finishedPointer = -1;
		private double nextDelay = 0;
		private Vector beats = new Vector();
		private BusyClock[] delayClocks;
		private int numClocks = 2;
		private double[] nextSequence = sequence;	

		public Voice(int number) {
			mynum = number;
			delayClocks = new BusyClock[numClocks];
			for (int i = 0; i < numClocks; i++) {
				delayClocks[i] = new BusyClock(this);
			}
		}
		public void setSeq(Atom[] seq) {

		}
		public void stop() {
			tick = 0;
			finishedPointer = -1;
			nextDelay = 0;
			beats.clear();
			sequence = nextSequence;
			for (int i = 0; i < delayClocks.length; i++) {
				delayClocks[i].unset();
			}
		}
		//************************************
		//                   THE BIG MAMMA
		//                   **************
		/*
			This is where the actual timing of events occurs.
		*/
		public void tick() {
			if (jam || tick == 0) {
				sequence = nextSequence;
			} 
			//TODO: Think hard about rounding error propagation.
			int totalSteps = Math.max(1, (int) Math.floor(sequence.length * cut * cloud));
			double ticksPerBeat = (double) grains /( totalSteps );
			// the number of steps forward after cutting and clouding.
			int numSteps = (int) Math.round(tick / ticksPerBeat);
			// the tick number to shoot for the next beat
			int beatTick = (int) Math.round(numSteps * ticksPerBeat);

			if (tick == beatTick) {
				// call the current beat (pointer is one beat old):
				if ((finishedPointer + 1)%(totalSteps) == numSteps) {
					// the position in the sequence.
					int seqPos = getSeqPos(tick, ticksPerBeat);
					// forward delays only for current beat (backward was already called):
					double delayTime = nextDelay;
					play(seqPos, delayTime);
					finishedPointer = (finishedPointer + 1) % totalSteps;
				}
				// call the next beat.  If the next beat delay is negative, execute;
				// otherwise store the positive delay for "current beat" execution 
				// on the next round.
				if (finishedPointer == numSteps) {
					int nextBeatTick = (int) Math.ceil((numSteps+1)*ticksPerBeat);
					int nextSeqPos = getSeqPos(nextBeatTick, ticksPerBeat);
					double delayTime = calculateDelay( nextSeqPos, ticksPerBeat );
					if (delayTime >= 0) {
						nextDelay = delayTime;
					} else {
						delayTime += ticksPerBeat * (period / grains);
						play(nextSeqPos, delayTime);
						finishedPointer = (finishedPointer + 1) % totalSteps;
					}
				}
			} 
			tick = (tick + 1) % grains;

		}
		// Calculate delay time based on sequence delay, jitter, and current
		// rate.  Delay time maxes out at beat length.
		private double calculateDelay(int seqPos, double ticksPerBeat ) {
			double maxDelay = ticksPerBeat * (period / grains); 
			double jitterAmt = (Math.random() - 0.5) * 2 * Math.min( maxDelay, jitter);
			double seqDelay = delays[ seqPos % delays.length ];
			double sum = jitterAmt + seqDelay;
			int sign = jitterAmt + seqDelay < 0 ? -1 : 1;
			double delayTime = Math.min(maxDelay, Math.abs(jitterAmt + seqDelay)) * sign;
			return delayTime;
		}
		public int getSeqPos(int ticks, double ticksPerBeat) {
			int elNum = (int) Math.round(ticks / ticksPerBeat * cloud);
			return elNum % sequence.length;
		} 
		// Play if we are active, and if we pass random check (if any).
		private void play(int seqPos, double delayTime) {
			if (active) {
				boolean play = true;	
				if (probs) {
					double rand = Math.random();
					play = rand < sequence[seqPos];
				}
				if (play) {
					beats.add( new Integer(seqPos) );
					for (int i = 0; i < delayClocks.length; i++) {
						if (!delayClocks[i].isBusy() || i == delayClocks.length) {
							delayClocks[i].delay(delayTime);
							return;
						}
					}
					// no unbusy clock found.  steal 0.
					delayClocks[0].delay(delayTime);
				}
			}
		}
		// Output the beat as bang, double, or payload, as specified.
		public void execute() {
			Integer beat = (Integer) beats.get(0);
			beats.remove(0);
			int seqPos = beat.intValue();

			if (bangs && sequence[seqPos] != 0) {
				// do bangs.
				outletBangHigh(mynum);
			} else if (payload == null) {
				// do sequence.
				outletHigh(mynum, sequence[seqPos] );
			} else {
				// do payload.
				double loadsize = (double)payload.length / sequence.length;
				int startPos = (int) Math.floor( seqPos * loadsize );
				int endPos = (int) Math.ceil( (seqPos + 1) * loadsize );
				Atom[] load = new Atom[endPos - startPos];
				for (int i = startPos, count=0; i < endPos; i++,count++) {
					load[count] = payload[i];
				}
				outletHigh(mynum, load);
			}			
		}
		/*
			Messages from Max to control each voice
		*/
		private void checkGrains() {
			if (nextSequence.length * cut * cloud > grains) {
				int beats = (int) Math.ceil(nextSequence.length * cut * cloud);
				MaxSystem.post("Voice "+mynum+": Error - more beats than grains ("+beats+" beats, "+grains+" grains)");
				MaxSystem.post("Rhythm will play incorrectly.  Increase num grains.");
			}
		} 
		private void command(String message, Atom[] data) {
			if (data.length == 0) {
				MaxSystem.post("invalid arguments for message "+message);

			} else if (message.equals("seq") || message.equals("list")) {
				nextSequence = new double[data.length];
				for (int i = 0; i < data.length; i++) {	
					nextSequence[i] = getDouble(data[i]);
				}
				checkGrains();

			} else if (message.equals("probs")) {
				this.probs = data[0].getInt() != 0;

			} else if (message.equals("bangs")) {
				this.bangs = data[0].getInt() != 0;

			} else if (message.equals("jam")) {
				this.jam = data[0].getInt() != 0;

			} else if (message.equals("jitter")) {
				this.jitter = getDouble(data[0]);

			} else if (message.equals("cut")) {
				this.cut = getDouble(data[0]);
				checkGrains();
	
			} else if (message.equals("cloud")) {
				double cl = getDouble(data[0]);
				this.cloud = cl >= 1 ? cl : 1;
				checkGrains();

			} else if (message.equals("start")) {
				this.active = true;

			} else if (message.equals("stop")) {
				this.active = false;
			
			} else if (message.equals("active")) {
				this.active = getDouble(data[0]) != 0.;

			} else if (message.equals("payload")) {
				payload = data;

			} else if (message.equals("clearpayload")) {
				payload = null;

			} else if (message.equals("delays")) {
				delays = new double[data.length];
				for (int i = 0; i < data.length; i++) {	
					delays[i] = getDouble(data[i]);
				} 

			} else if (message.equals("thru")) {
				outlet(mynum, data); 

			} else {
				MaxSystem.post("error - unknown message " + message);	

			}
		}	
		public double getDouble(Atom a) {
			if (a.isFloat()) {
				return (double) a.getFloat();
			} else if (a.isInt()) {
				return (double) a.getInt();
			} else {
				return 0;
			}
		}
		public void notifyDeleted() {
			for (int i = 0; i < delayClocks.length; i++) {
				delayClocks[i].notifyDeleted();
			} 
		}
	}
	/*
		Like MaxClock, but with an "isBusy" method.
	*/
	private class BusyClock extends MaxClock implements Executable {
		private Executable exec;
		private boolean busy = false;	
		public BusyClock(Executable obj) {
			super();
			super.setExecutable(this);
			this.exec = obj;
		}
		public void delay(double time) {
			this.busy = true;
			super.delay(time);
		}
		public void execute() {
			exec.execute();
			this.busy = false;
		}
		public void unset() {
			super.unset();
			this.busy = false;
		}
		public boolean isBusy() {
			return busy;
		}
		public void notifyDeleted() {
			unset();
			release();
		}
	}
}






