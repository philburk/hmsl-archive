import com.cycling74.max.*;
import java.util.Random;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class AnnasPitchChooser extends MaxObject
{
	private static final int C = 0;
	private static final int Db = 1;
	private static final int D = 2;
	private static final int Eb = 3;
	private static final int E = 4;
	private static final int F = 5;
	private static final int Gb = 6;
	private static final int G = 7;
	private static final int Ab = 8;
	private static final int A = 9;
	private static final int Bb = 10;
	private static final int B = 11;
		
	private static HashMap scales = new HashMap();

	//********  Attributes
    private int key = C;
	private double stepprob = 0.1;
	private double repeatprob = 0.1;
	private int memoryDepth = 8;
	private int[] range = new int[] { 60,12 };
	private String mood = "major";
	//********  Instance vars
	private int[] moodNotes;	
	private int[] memory; // memory for notes
	private int memoryPointer; // where the next note goes
	private Random random;

	public AnnasPitchChooser(Atom[] args)
	{
		scales.put("chrom", new int[] { C, Db, D, Eb, E, F, Gb, G, Ab, A, Bb, B } );
	    scales.put("major",  new int[] { C, D, E, F, G, A, B });
	    scales.put("minor",  new int[] { C, D, Eb, F, G, Ab, B });
	    scales.put("pent",  new int[] { C, D, E, G, A });
	    scales.put("m-pent", new int[] { C, D, Eb, G, Ab });
	    scales.put("blues",  new int[] { C, D, Eb, E, Gb, G, A, Bb});
	    scales.put("dim", new int[] { C, D, Eb, F, Gb, Ab, A, B });
	    scales.put("whole",  new int[] { C, D, E, Gb, Ab, Bb });
	    scales.put("pelog",  new int[] { C, Db,E, G, Ab });
	    scales.put("#-lyd", new int[] { C, D, E, Gb, Ab, A, B });

		setMood("major");

		declareInlets(new int[]{DataTypes.ALL});
		declareOutlets(new int[]{DataTypes.ALL});
	
		declareAttribute("stepprob");
		declareAttribute("repeatprob");
		declareAttribute("memoryDepth", "getMemoryDepth", "setMemoryDepth");
		declareAttribute("mood", "getMood", "setMood");
		declareAttribute("range");		
		declareAttribute("key");		

		memory = new int[ memoryDepth * 2 ];
		
		random = new Random();
	}
	//**************************
	//               Inlets
	//               *********
	private void setMood(String mood) {
		int[] newMood = (int[]) scales.get(mood);
		if (newMood == null) {
			MaxSystem.post("Error - unknown mood " + mood);
			return;
		} else {
			moodNotes = newMood;
		}
		this.mood = mood;
	}
	public String getMood() {
		return mood;
	}
	public void setMemoryDepth(int depth) {
		if (memory.length < depth) {
			int[] newMemory = new int[depth * 2];
			for (int i = 0; i < memory.length; i++) {
				newMemory[i] = memory[i];
			}
			memory = newMemory;
			memoryDepth = depth;
		}
		
	}
	public int getMemoryDepth() {
		return memoryDepth;
	}
	public void bang() {
		int note = pickNote();
        addToMemory(note);
		outlet(0,note);		
	}
	//****************************
	//               The Real Work
	//               *********
	
	private int pickNote() {

		boolean doRepeat = random.nextDouble() <= repeatprob;
		boolean doStep = random.nextDouble() <= stepprob;

		if (doRepeat) {
			int rep = recall( (int) repeatprob * memoryDepth );
			if (rep != 0) {
				return rep;
			} 
		}			 
		if (doStep) {
            int current = recall(-1);
            int above = current + 1;
            int below = current - 1;
            while (degreeInCurrentMood(above) == -1) {
                above += 1;
            }
            while (degreeInCurrentMood(below) == -1) {
                below -= 1;
            }
			
			int choice;
            if (above <= rangeTop() && below >= rangeBottom()) {
				choice = random.nextDouble() < 0.5 ? above : below;
			} else if (above <= rangeTop()) {
                choice = above;
            } else if (below >= rangeBottom()) {
                choice = below;
            } else {
                choice = current;
            }
			return choice;
		}
        // just do a random note in the range

        // this complexity is necessary because we must allow for ranges
        // smaller than 12 which honor key selection.
        List notes = new ArrayList();
        for (int i = rangeBottom(); i <= rangeTop(); i++) {
            if (degreeInCurrentMood(i) != -1) {
                notes.add(new Integer(i));
            } 
        }
        if (notes.size() > 0) {
            int pick = random.nextInt(notes.size());
            return (int) ((Integer) notes.get(pick)).intValue();
        } else {
            return recall(-1);
        }
	}

	/*
		Memory
	*/
	private void addToMemory(int note) {
		memory[memoryPointer] = note;
		memoryPointer = (memoryPointer + 1) % memoryDepth;
	}
	private int recall(int index) {
		int memindex = (memoryPointer + memoryDepth + index) % memoryDepth;
		return memory[memindex];
	}
	/*
	  binary search.  Returns scale degree of note if it is in, or -1 otherwise.
	*/
	private int degreeInCurrentMood(int note) {
		int pitchClass = getPitchClass(note);
		int top = moodNotes.length - 1;
		int bottom = 0;
		while (true) {
			if (moodNotes[top] == pitchClass) {
				return top;
			} else if (moodNotes[bottom] == pitchClass) {
				return bottom; 
			} else if (top - bottom <= 1) {
				return -1;
			} 
			int middle = (top - bottom) / 2 + bottom;

			if (moodNotes[middle] < pitchClass) {
				bottom = middle;
			} else {
				top = middle;
			}
		}
	}
	/*
		range helpers
	*/
	private int getPitchClass(int num) {
		// java % operator leaves numbers negative, hence the + and remodding.
		return (((num - key) % 12) + 12) % 12;
	}
	private int rangeTop() {
		return Math.min(127, range[0] + range[1]);
	}
	private int rangeBottom() {
		return Math.max(0, range[0]);
	}
	private void printArray(int[] array) {
		String out = "";
		for (int i = 0; i < array.length; i++) {
			out += array[i] + " ";
		}
		MaxSystem.post(out);	
	}
}
